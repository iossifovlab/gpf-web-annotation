from django.apps import AppConfig


class WebAnnotationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gpf_web_annotation_backend'
    label = 'gpf_web_annotation_backend'
